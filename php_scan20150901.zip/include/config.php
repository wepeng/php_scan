<?php
	$_config = array();
	$_config['db']['dbhost'] = 'localhost';
	$_config['db']['dbcharset'] = 'utf8';
	
	$_config['db']['dbuser'] = 'root';
	$_config['db']['dbpw'] = '123456';
	$_config['db']['name'] = 'php_scan';
?>