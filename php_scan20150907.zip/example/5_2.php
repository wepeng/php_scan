﻿<?php
/**
* 测试用例
*
* 环判断
*/
//过程A
echo 'B';

//显示管理界面
include '5_1.php';

?>